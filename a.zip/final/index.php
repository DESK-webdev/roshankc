<?php
include 'include/plates.php';
include 'include/include.php';
    ///session check
    session_start();
    if($_SESSION){
        $logged=1;
    }
    else{
        $logged=0;
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Food_version_2.0</title>
<!------ Link to css ------->
<link rel="stylesheet" href="css/style.css">
<!-- <link rel="stylesheet" href="./css/owl.carousel.min.css"> -->
<!-- <link rel="stylesheet" href="css/nav.css"> -->
</head>
<body>
<?php include 'include/nav.php'; nav($logged,$logged); ?>
<main>
    <div class="container">  <!--Burger pic here-->
        <form action="#" class="form-inline">
            <div class="search-box">
                <input type="text" placeholder="Search" name="Search" >
            
                <button class="btn button" type="submit">Submit</button>
            </div>
         </form>
        <div class="site-main">
            <div class="site-title">
                <h1>Foods and Services</h1>
            </div>
            <div class="site-body">
                <h3>Our Services</h3>
                <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Exercitationem vero fuga veniam nemo odit ab delectus doloremque fugiat iste sunt consequuntur tenetur, vel accusamus quasi eveniet aspernatur deleniti incidunt vitae? Cum, numquam perferendis. Mollitia in est voluptas veritatis nemo rerum.</p>
            </div>
        </div>
        
        
    </div>
</main>    

<!--Carousels-->
<?php plate("%"); ?>

<footer>
    <div class="footer-body">
        <div class="aboutus">
            <h2>About us</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Aspernatur esse quam quibusdam, beatae consequatur itaque excepturi consequuntur cum, quo corruption repudiandae! Nemo tempore exercitationem voluptatum ad iusto, doloremque deserunt optio! In corrupti eligendi veritatis ratione consequatur placeat deleniti error sit!</p>
        </div>
        <div class="our-services">
            <h2>Our Services</h2>
            <p>Our Opening time:</p>
            <br>
            <p>Sunday to Thursday: 9:00am to 4:30pm</p>
            <p> </p>
            <br> 
            <p>Friday: 9:00am to 2:00pm</p>
            <br>
            <p>Saturday: Closed</p>
        </div>
        <div class="contact-us">
            <h2>Contact us</h2>
            <div class="small-contact-us">
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Ullam quasi molestiae ratione quisquam. Quia tenetur facilis consectetur veritatis fugiat natus necessitatibus expedita animi consequuntur, voluptatem totam praesentium sint eligendi porro magni dolores architecto nulla at nobis itaque dolorum ex eius! Natus saepe, nemo consectetur aliquid ipsa quas aliquam cupiditate minus tempore doloribus reiciendis magni qui numquam odio a, hic enim.</p>
                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Odio laudantium veniam quasi, iusto quisquam reiciendis labore porro! Velit, architecto a sunt, assumenda doloremque repellendus repudiandae minus veniam excepturi eaque ducimus?</p>
            </div>
        </div>
        <div class="news-notices">
            <h2>News and Notices</h2>
            <a href="#">>> This is one notice.<a><br>
            <a href="#">>> Click in this News.</a><br>
            <a href="#">>> This is one notice.<a><br>
            <a href="#">>> Click in this News.</a><br>
            <a href="#">>> This is one notice.<a><br>
            <a href="#">>> Click in this News.</a><br>
            <a href="#">>> This is one notice.<a><br>
            <a href="#">>> Click in this News.</a><br>
            <a href="#">>> This is one notice.<a><br>
           
          
        </div>
    </div>
    <div class="copyright">
        <h4>2020 @ copyright: <a href="#">Anjan_Poudel</a></h4>
    </div>
</footer>
</body>
</html>
