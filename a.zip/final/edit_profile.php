<?php
    include 'include/include.php';
    ///session check
    session_start();
    if(!$_SESSION){
        header("Location: login.php");
    }
?>
<?php
$error="";
    if($_GET['enter']){   ///if 0 is passed to any form not accepted
        $conn=sql_connect("sql1");
        if(!$conn){die(mysqli_connect_error());}
        //$query=mysqli_query($conn,"");
        $query=mysqli_query($conn,'select * from hotel 
        where id="'.$_SESSION['id'].'" and password="'.hash("md5",$_GET['password']).'";');
        if(!$query) {echo mysqli_error($conn);echo "not";}
        $data=mysqli_fetch_all($query);
        if(!$data){echo mysqli_error($conn);}
        else{
            $query=mysqli_query($conn,'update hotel set name="'.$_GET['hotel_name'].'"  
                    where id="'.$_SESSION['id'].'" and password="'.hash("md5",$_GET['password']).'";');
            if(!$query) {echo mysqli_error($conn);echo "not";}
            $query=mysqli_query($conn,'update hotel_bio set hotel_name="'.$_GET['hotel_name'].'",
                                                                manager_name="'.$_GET['name'].'",
                                                                email="'.$_GET['email'].'",
                                                                location="'.$_GET['location'].'",
                                                                open_time="'.$_GET['open'].'",
                                                                close_time="'.$_GET['close'].'",
                                                                bio="'.$_GET['info'].'" 
                                                                where id="'.$_SESSION['id'].'";');
            if(!$query) {echo mysqli_error($conn);echo "not";}
            else{
                $_SESSION['name']=$_GET['hotel_name'];
                header("Location: profile.php");
            }
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Profile Hotel</title>
    <link rel="stylesheet" href="css/style.css">
   <!-- <link rel="stylesheet" href="css/nav.css"> -->
   <link rel="stylesheet" href="css/profile.css">
</head>
<body>
<div class="profile">
        <div class="profile-hotel">
            <div class="profile-data">
            <?php 
            echo "<form method=\"GET\">
                <input type=\"hidden\" value=\"1\" name=\"enter\" />
                <h2>Hotel name:<input name=\"hotel_name\" value=\"".$_GET['hotel_name']."\"></input></h2>
                <h3>Name:<input name=\"name\" value=\"".$_GET['name']."\"></input></h3>
                <h3>Email:<input name=\"email\" value=\"".$_GET['email']."\"></input></h3>
                <h3>Location:<input name=\"location\" value=\"".$_GET['location']."\"></input></h3>
                <h3>Opening:<input name=\"open\" value=\"".$_GET['open']."\"></input><br> 
                Closing: <input name=\"close\" value=\"".$_GET['close']."\"></input></h3>
                <h2>Bio:<input name=\"info\" value=\"".$_GET['info']."\"></input></h2>
                <h3>input password to conform:<br><input name=\"password\" type=\"password\"></input></h3>
                <input type=\"submit\"></input>
                </form>";
            ?>
            </div>
        </div>
</div>
</body>
</html>