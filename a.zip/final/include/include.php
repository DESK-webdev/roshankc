<?php
    function sql_connect($xml_file){
        $sql=simplexml_load_file("../../".$xml_file.".xml");
        $conn=mysqli_connect($sql->host,$sql->user,$sql->password,$sql->database);
        if(!$conn){return 0;}
        else return $conn;
    }
?>