<?php
     ///session check
    session_start();
    if($_SESSION['name'] && $_SESSION['phone'] && $_SESSION['id']){
        header("Location: profile.php");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Register_form</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/nav.css">
    <link rel="stylesheet" href="css/register.css">
</head>
<body>
<?php 
if(!$_GET['cache']){
        echo '<div id="table_option">
        <table>
            <tr>
                <td></td>
                <td>    
                        <div class="box_container">
                        <a href="?cache=1"><button>As hotel owner</button> </a>
                        <a href="?cache=2"><button>As student</button> </a>
                        </div>
                </td>
                <td></td>
    
                 </tr>
               
        </table>
      </div>';
} 
else {
?>
<?php include 'include/nav.php';nav(0,0); ?>
<div class="register_container_3" id="register_container_3">
        <div class="register_form_3">
        <?php
        if($_GET['cache']=="1"){
        echo'        
                <form action="include/data_store.php" method="GET">
                <h1>Register Your Form</h1>
                <input type="hidden" value="1" name="cache" /> 
                <label for="#">Hotel name:
                <input type="text" name="a_name" placeholder="Hotel_name" />
                </label>
                ';
                }
        else if($_GET['cache']=="2"){
        echo '
                <form action="include/data_store.php" method="GET">
                <h1>Register Your Form</h1>
                <input type="hidden" value="2" name="cache" /> 
                <label for="student name">Student-name:
                <input type="text" name="a_name" placeholder="Name" />
                </label>
                ';
        }
        else {header("Location: register.php");}
        ?>
                <label for="contact number">Contact-number: 
                <input type="number" name="phone" placeholder="Mobile-number">
                </label>
                <label for="password">Password:
                <input type="password" name="password" placeholder="Password">
                </label>
                <label for="retype password">Retype Password:
                <input type="password" name="re_password" placeholder="Password">
                </label> 
                <button>Submit</button>
            </form>
         </div>
  <div class="location-info">
    <h5> * For location outside Pokhara-lamachaur,contact us at 9802020202</h5>
  </div>
</div>
        <?php } ?>
</body>
</html>