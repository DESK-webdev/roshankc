<?php
    echo '<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Food_version_2.0</title>
<!------ Link to css ------->
<link rel="stylesheet" href="css/style.css">

<!------------ link to all ------------>
<link rel="stylesheet" href="css/all.css">
<link rel="stylesheet" href="css/nav.css">
</head>

';
?>