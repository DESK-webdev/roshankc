<?php
include 'include/plates.php';
include 'include/include.php';
include 'include/nav.php';
    session_start();
    if($_SESSION){
       $logged=1;
    }
    else{
    $logged=0;
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Profile Hotel</title>
</head>
<link rel="stylesheet" href="css/style.css">
<!--link to owl-carousel-->
<!-- <link rel="stylesheet" href="css/owl.carousel.min.css"> -->
<link rel="stylesheet" href="css/owl.theme.default.min.css">
<link rel="stylesheet" href="css/gallery.css">
<body>
    <?php nav($logged,$logged); ?>
<div class="fastfood-css">
<h2>Following foods are currently available.</h2>
</div>
    <form action="#" class="form-inline fastfood_form">
        <div class="search-box">
            <input type="text" placeholder="Search by id/name" name="Search">
            <button class="btn button" type="submit">Submit</button>
        </div>
    </form>
<div class="fastfood">
    <h2 class="left">Our top foods</h2>
    <?php plate("%"); ?>
</div>

<div class="fastfood_all">
    <div class="fastfood_rect">
        <div class="fastfoodrect_img">
            <img src="./assets/sandwitch.jpg" alt="pic">
        </div>
        <div class="fastfoodrect_descp">
            <h2 class="left">1.Heading</h2>
            <p class="left f15">Lorem ipsum dolor sit amet consectetur adipisicing elit. Cupiditate, nulla</p>

            <form action="./order_details.html">
                <button type="submit" class="btn btnright">Order details</button>
            </form>
            
        </div>
    </div>
    <div class="fastfood_rect">
        <div class="fastfoodrect_img">
            <img src="./assets/sandwitch.jpg" alt="pic">
        </div>
        <div class="fastfoodrect_descp">
            <h2 class="left">1.Heading</h2>
            <p class="left f15">Lorem ipsum dolor sit amet consectetur adipisicing elit. Cupiditate, nulla</p>

            <form action="./order_details.html">
                <button type="submit" class="btn btnright">Order details</button>
            </form>
        </div>
    </div>
    <div class="fastfood_rect">
        <div class="fastfoodrect_img">
            <img src="./assets/sandwitch.jpg" alt="pic">
        </div>
        <div class="fastfoodrect_descp">
            <h2 class="left">1.Heading</h2>
            <p class="left f15">Lorem ipsum dolor sit amet consectetur adipisicing elit. Cupiditate, nulla</p>

            <form action="./order_details.html">
                <button type="submit" class="btn btnright">Order details</button>
            </form>
           
        </div>
    </div>
    <div class="fastfood_rect">
        <div class="fastfoodrect_img">
            <img src="./assets/sandwitch.jpg" alt="pic">
        </div>
        <div class="fastfoodrect_descp">
            <h2 class="left">1.Heading</h2>
            <p class="left f15">Lorem ipsum dolor sit amet consectetur adipisicing elit. Cupiditate, nulla</p>

            <form action="./order_details.html">
                <button type="submit" class="btn btnright">Order details</button>
            </form>
           
        </div>
    </div>
</div>

        
<!--link to jquery-->
<script src="./js/Jquery3.4.1.min.js"></script>
<!--Link to owl-carousel-->
<script src="./js/owl.carousel.min.js"></script>
<!--Link to js-->
<script src="./js/main.js"></script>

   
</body>
</html>