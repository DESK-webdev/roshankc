<?php 
include 'include/include.php';
include 'include/nav.php';
    session_start();
    if($_SESSION){
       $logged=1;
    }
    else{
    $logged=0;
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Food_version_2.0</title>
</head>
<!------ Link to css ------->
<link rel="stylesheet" href="css/style.css">
<!------------ link to all ------------>
<link rel="stylesheet" href="css/hotels.css">
<body>
<?php nav($logged,$logged); ?>
<hr class="top_line">
<main>
    <form action="#" class="form-inline">
        <div class="search-box">
            <input type="text" placeholder="Search by id/name" name="Search" >

            <button class="btn button" type="submit">Submit</button>
        </div>
    </form>
    <button type="button" class="btn filters">Filters</button>
</main>    
<div class="order_details_hotel_txt">
    <h2>Registered Hotels</h2>
</div>
<?php 
    $conn=sql_connect("sql1");
    if(!$conn){die(mysqli_connect_error());}
    $query=mysqli_query($conn,"select manager_name,hotel_name,photoid,location,public_id from hotel_bio limit 5;");
    $data=mysqli_fetch_all($query);
    if(!$data){echo mysqli_error($conn);die("you havent provided enough information about you!!");}
    $i=0;
    while($data[$i]){
        echo '
    <div class="hotel">
        <div class="order_hotel_pic">
            <img src="image/'.$data[$i][2].'.png" alt="'.$data[$i][1].'">
        </div>
        <div class="order_hotel_descp">
            <div class="order_hotel_title">
                <h3>'.$data[$i][1].'</h3>
                <h3>id:'.$data[$i][4].'</h3>
            </div>
            <hr>
            <div class="order_hotel_sub_title">
                <p>Manager Name: '.$data[$i][0].'</p>
                <p>Address: '.$data[$i][3].'</p>
                <p>Active Status: 
                    <i  class="fas fa-circle"></i> 
                 </p>               
            </div>
                <a href="profile.php?id='.$data[$i][4].'&type=hotel" class="btn btnright">more</a>
        </div>
    </div>';
    $i++;        
    }
?>
</body>
<!--link to jquery-->
<script src="./js/Jquery3.4.1.min.js"></script>
<!--Link to owl-carousel-->
<script src="./js/owl.carousel.min.js"></script>
<!--Link to js-->
<script src="./js/main.js"></script>
</html>
