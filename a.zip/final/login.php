<?php
    include 'include/include.php';
    ///session check
    session_start();
    if($_SESSION['name'] && $_SESSION['phone'] && $_SESSION['id']){
        header("Location: profile.php");
    }
?>
<?php
$error="";
    if(($num=$_GET['number']) && ($pass=$_GET['password'])){   ///if 0 is passed to any form not accepted
        $conn=sql_connect("sql1");
        if(!$conn){die(mysqli_connect_error());}
        $query=mysqli_query($conn,"select * from hotel where phone_number=\"$num\" and 
                                            password=\"".hash("md5",$pass)."\";");
        if(!$query) {mysqli_error($conn);}
        $data=mysqli_fetch_all($query);
        if(!$data){$error="Incorrect username or password!!";}
        else{
            session_start();
            $_SESSION['name']=$data[0][1];
            $_SESSION['type']=$data[0][2];
            $_SESSION['phone']=$data[0][3];
            $_SESSION['id']=$data[0][5];          
            header("Location: profile.php");
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Food_version_2.0</title>
<!------ Link to css ------->
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/nav.css">
<link rel="stylesheet" href="css/login.css">
</head>

<body>
<?php include 'include/nav.php';nav(0,0); ?>
<!--Login Section-->
<div class="login-section">
    <div class="logo">
        <h3>Logo</h3>
    </div>
    
    <div class="motto">
        <h4>Lorem ipsum dolor, sit amet consectetur adipisicing elit.</h4>
    </div>
    <div class="login-body">
        <h2>Login:</h2>
        <form action="login.php" class="login-form">
            <div class="number">
                <label for="number"></label>
                <input type="text" id="number" placeholder="Type Number (980********)" name="number" required>
            </div>
            <div class="password">
                <label for="password"></label>
                <input type="password" id="password" placeholder="Type password" name="password" required>
            </div>
            <?php echo $error; ?>
            <div class="remem_me">
                <label for="checkbox">
                    <input type="checkbox" id="checkbox" name="checkbox" >
                    Remember Me
                </label>
            </div>
            <button class="btn" type="submit">
                Submit
            </button>
            <a href="./register.php" class="btn">Create account</a>
        </form>
    </div>
</div>
</body>
</html>