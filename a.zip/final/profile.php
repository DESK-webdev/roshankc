<?php
    include 'include/include.php';
    include 'include/plates.php';
    session_start();
    if($_SESSION){
        $logged=1;
     }
     else{
     $logged=0;
     }
    //if(!$_SESSION['who']) header("Location: index.php");
    $name=$_SESSION['name'];
    $phone=$_SESSION['phone'];
    $s_type=$_SESSION['type'];  ///session type
    $g_type=$_GET['type'];       //get type
    $local_id=$_GET['id'];
        $conn=sql_connect("sql1");
        if(!$conn){die(mysqli_connect_error());}
    if(!$_GET['id'] || !$_GET['type']){
        $query=mysqli_query($conn,"select * from ".$s_type."_bio where id='".$_SESSION['id']."';");
    }
    else{
        $query=mysqli_query($conn,"select * from ".$g_type."_bio where public_id='".$local_id."';");
    }
        $data=mysqli_fetch_all($query);
        if(!$data){echo mysqli_error($conn);die("you havent provided enough information about you!!");}
        $query=mysqli_query($conn,"select name,type,phone_number from hotel where id='".$data[0][1]."';");
        $data_1=mysqli_fetch_all($query);
        if(!$data_1){echo mysqli_error($conn);die("you havent provided enough information about you!!");}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Profile Hotel</title>
    <link rel="stylesheet" href="css/style.css">
   <!-- <link rel="stylesheet" href="css/nav.css"> -->
   <link rel="stylesheet" href="css/profile.css">
</head>
<body>
    <?php include 'include/nav.php'; nav($logged,$logged); ?>
    <div class="profile">
    <?php if($s_type=="hotel" || $g_type=="hotel"){ ?>
        <div class="profile-hotel">
            <div class="pic">
                <div class="cover-pic" style="background:url(<?php echo "/image/".$phone.".png"; ?>);">
                    <div class="profile-pic">
                        <img src="<?php echo "../image/".$data[0][3].".png"; ?>" alt="">
                    </div>
                </div>
            </div>
            <div class="profile-data">
            <?php 
                if($_SESSION['id']==$data[0][1]){
                echo '<a href="edit_profile.php?hotel_name='.$data_1[0][0].
                                                '&name='.$data[0][3].
                                                '&phone='.$data_1[0][2].
                                                '&email='.$data[0][5].
                                                '&location='.$data[0][6].
                                                '&open='.$data[0][8].
                                                '&close='.$data[0][9].
                                                '&info='.$data[0][10].'">
                                                <h4 style="float:right;color:blue;">edit</h3></a>';
                                                $_SESSION['local_id']=$data[0][7];
                                            }
            ?>
            <?php 
            echo "<h2>".$data_1[0][0]."</h2>
                <h2>".$data[0][2]."</h2>
                <h3>Name:".$data[0][3]."</h3>
                <h3>Ph no:".$data_1[0][2]."</h3>
                <h3>User id:".$data[0][7]."</h3>
                <h3>Email:".$data[0][5]."</h3>
                <h3>Location:".$data[0][6]."</h3>
                <h3>Opening: ".$data[0][8]." -- Closing: ".$data[0][9]."</h3>
                <h2>".$data[0][10]."</h2>";
            ?>
            </div>
        </div>
    </div>
    <?php } 
    else if($s_type="student" || $g_type=="student"){ ?>
        <div class="profile_customer">
            <div class="customer_describe">
                <?php echo '
                <div class="customer_image">  
                <img src="../image/'.$data[0][2].'.png" alt="your picture">
                </div>
                <div class="child_data">
                <h3>Name: '.$data[0][6].'</h3>
                <h3>Phone no:'.$phone.'</h3>
                <h3>Address: '.$data[0][4].'</h3>
                <h3>Best Food:MOMO</h3>
                <h3>!!! '.$food[0][5].' !!!</h3>
                <br>
                <h3>Other info</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Natus at ad reiciendis doloremque, facere explicabo? Facilis eveniet laudantium incidunt doloribus?</p>
                </div>';  
                ?>
            </div>
        </div>
    <?php }
    else {echo "who are you";} ?>
    <hr>
<hr><br>
<h3>We have foods listed below:</h3>
    <!--Carousels-->
    <?php plate($data[0][7]); ?>
    <footer>
    <div class="footer-body">
        <div class="aboutus">
            <h2>About us</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Aspernatur esse quam quibusdam, beatae consequatur itaque excepturi consequuntur cum, quo corruption repudiandae! Nemo tempore exercitationem voluptatum ad iusto, doloremque deserunt optio! In corrupti eligendi veritatis ratione consequatur placeat deleniti error sit!</p>
        </div>
        <div class="our-services">
            <h2>Our Services</h2>
            <p>Our Opening time:</p>
            <br>
            <p>Sunday to Thursday: 9:00am to 4:30pm</p>
            <p> </p>
            <br> 
            <p>Friday: 9:00am to 2:00pm</p>
            <br>
            <p>Saturday: Closed</p>
        </div>
        <div class="contact-us">
            <h2>Contact us</h2>
            <div class="small-contact-us">
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Ullam quasi molestiae ratione quisquam. Quia tenetur facilis consectetur veritatis fugiat natus necessitatibus expedita animi consequuntur, voluptatem totam praesentium sint eligendi porro magni dolores architecto nulla at nobis itaque dolorum ex eius! Natus saepe, nemo consectetur aliquid ipsa quas aliquam cupiditate minus tempore doloribus reiciendis magni qui numquam odio a, hic enim.</p>
                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Odio laudantium veniam quasi, iusto quisquam reiciendis labore porro! Velit, architecto a sunt, assumenda doloremque repellendus repudiandae minus veniam excepturi eaque ducimus?</p>
            </div>
        </div>
        <div class="news-notices">
            <h2>News and Notices</h2>
            <a href="#">>> This is one notice.<a><br>
            <a href="#">>> Click in this News.</a><br>
            <a href="#">>> This is one notice.<a><br>
            <a href="#">>> Click in this News.</a><br>
            <a href="#">>> This is one notice.<a><br>
            <a href="#">>> Click in this News.</a><br>
            <a href="#">>> This is one notice.<a><br>
            <a href="#">>> Click in this News.</a><br>
            <a href="#">>> This is one notice.<a><br>
           
          
        </div>
    </div>
    <div class="copyright">
        <h4>2020 @ copyright: <a href="#">Anjan_Poudel</a></h4>
    </div>
</footer>
</body>
</html>