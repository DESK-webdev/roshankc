
<?php
include 'include/include.php';
include 'include/plates.php';
 session_start();
 if($_GET['food_id']){
    $name=$_SESSION['name'];
    $phone=$_SESSION['phone'];
    $type=$_SESSION['type'];
    $ids=split_id($_GET['food_id']);
        $conn=sql_connect("sql1");
        if(!$conn){die(mysqli_connect_error());}
        $query=mysqli_query($conn,"select hotel_name,location,
                                    open_time,close_time,email 
                                    from hotel_bio where public_id='".$ids[0]."'");
        $hotel=mysqli_fetch_all($query);
        //print_r($hotel);
        $query=mysqli_query($conn,"select * from foods_global where food_id='".$ids[1]."'");
        $global=mysqli_fetch_all($query);
        //print_r($global);
        if(!$global){echo mysqli_error($conn);die("you havent provided enough information about global food!!");}
        $query=mysqli_query($conn,"select * from foods where food_id like '".$ids[0].$ids[1]."%'");
        $local=mysqli_fetch_all($query);
        //print_r($local);
        if(!$local){echo mysqli_error($conn);die("you havent provided enough information about local food!!");}
 }
 else{
     header("Location: gallery.php");
 }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/food_box.css">
<body>
    <?php include 'include/nav.php'; nav(0,$_SESSION!=NULL);?>
    <div class="view_it_container">
        <div class="view_it_image">
            <?php echo '<img src="image/'.$local[0][5].'.png" alt="'.$global[0][2].':'.$local[0][2].'">'; ?>
        </div>
        <div class="view_it_flex">
        <?php echo ' 
            <h1>'.$global[0][2].'</h1>
            <p>'.$global[0][5].'</p>';
            ?>
        </div>
    </div>
        <h1>Menu for variety of <?php echo $data[0][2]; ?>s</h1>
            <table style="width:100%" class="food_option_table">
                <tr>
                    <th>S.N</th>
                    <th>Name</th>
                    <th>Price(Rs)</th>
                  <th>Rating</th>
                  <th>Coming time</th>
                  <th>quantity</th>
                <th>order</th>
                </tr>
                <?php
                $i=0;
                while($local[$i]){
                echo '
               <form action="#">
                <tr>
                    <td>'.$i.'</td>
                    <td>'.$local[$i][2].'</td>
                    <td>'.$local[$i][3].'</td>
                    <td>'.$local[$i][7].'</td>
                    <td><input type="time"  name="time" class="timebox"
                        placeholder="time"> </td>
                        <td><select name="quantity">
                            <option value="1">half</option>
                            <option value="1">full</option>
                        </select> </td>
                        <td><button>ordered now</button> </td>
                </tr>
               </form>
               ';
               $i++;
                }
               ?>
            </table>
    <h1>More <?php echo $global[0][2]; ?>s</h1>
    <?php plate($ids[1]); ?>
</body>
</html>