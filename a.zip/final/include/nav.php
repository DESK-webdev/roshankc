<?php
   
 function nav($first,$last){
    if($first!='0'){
        $nav_status='<li class="nav-link"> 
        <a href="/profile.php">profile</a>
            </li>';
    }
    else{
        $nav_status='';
    }   
    if($last!='0'){
           $nav_last="Logout";
           $nav_anchor_last="include/logout.php";
       }
       else{
           $nav_last="Log/Sign";
           $nav_anchor_last="login.php";
       }
    echo '<nav>
    <div class="nav-menu flex-row">
        <div class="navbar-brand">
            <a href="#"><h2>foodie</h2></a>
        </div>

        <div class="toggle-collapse">
            <div class="toggle-icons">
                <i class="fas fa-bars">
                </i>
            </div>
        </div>
    
        <div>
            <ul class="nav-items">
                <li class="nav-link"> 
                <a href="/">home</a>
                </li>
                '.$nav_status.'
                <li class="nav-link"> 
                    <a href="gallery.php">Gallery</a>
                </li>
                <li class="nav-link"> 
                    <a href="/hotels.php">hotels</a>
                </li>
                <li class="nav-link"> 
                    <a href="/'.$nav_anchor_last.'">'.$nav_last.'</a>
                </li>
            </ul>
        </div>
        <div class="social">
            <a href="#"><i class="fab fa-facebook"></i></a>
            <a href="#"><i class="fab fa-youtube"></i></a>
            <a href="#"><i class="fab fa-twitter"></i></a>
            <a href="#"><i class="fab fa-instagram"></i></a>
        </div>
    </div>
</nav>';
}
?>