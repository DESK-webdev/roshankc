<?php
    function split_id($id){
        $piece[0]=$id[0].$id[1].$id[2].$id[3];  //for hotel
        $piece[1]=$id[4].$id[5].$id[6].$id[7];  //for global food
        $piece[2]=$id[8].$id[9];                //for foods
        return $piece;
    }
?>
<?php
function plate($id){
        //$piece=split_id($id);
        $conn=sql_connect("sql1");
        if(!$conn){die(mysqli_connect_error());}
        $query=mysqli_query($conn,"select 
                                    food_id,
                                    food_name,
                                    imageid,
                                    left(food_bio,30),
                                    parent_food  
                            from foods where food_id like '%".$id."%' order by food_rating limit 4;");
        if(!$query) {mysqli_error($conn);}
        $data=mysqli_fetch_all($query);
        // $query=mysqli_query($conn,"select * from hotel_bio where id='".$piece[0]."';");
        // if(!$query) {mysqli_error($conn);}
        // $data_hotel=mysqli_fetch_all($query);
        // $query=mysqli_query($conn,"select * from foods_global where id='".$piece[1]."';");
        // if(!$query) {mysqli_error($conn);}
        // $data_hotel=mysqli_fetch_all($query);
    ?>
    <section>
        <div class="products">
            <div class="owl-carousel carousel">
            <?php
            $i=0;
            while($data[$i]){
            echo '
            <div class="product-items">
                    <div class="product-image">
                        <img src="image/'.$data[$i][2].'.png" alt="'.$data[$i][2].'">
                    </div>
                    <div class="product-describe">
                        <h2>'.$data[$i][4].':'.$data[$i][1].'</h2>
                        <p>'.$data[$i][3].'</p>
                        <a href="/food_box.php?food_id='.$data[$i][0].'"><button class="btn">View it</button></a>
                    </div>
                </div>';
                $i++;
            }
            ?>
            </div>
        </div>
    </section>
<?php }
    //plate("h");
?>