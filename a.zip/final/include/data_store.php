<?php
   function add_image($img_name){
      $fp=fopen($_FILES['image']['tmp_name'],'r');
      $fp_w=fopen("../image/".$img_name.".png",'w');
      $x=fread($fp,$_FILES['image']['size']);
      fwrite($fp_w,$x);
      fclose($fp_w);
      fclose($fp);
   }
   function tostring(){
      return $_GET['phone'].$_GET['password'].$_GET['a_name'].$_GET['cache'];
   }
   function hotelid($sn){
      switch(strlen($sn)){
          case 1:
              return "h00".$sn;
          break;
          case 2:
              return "h0".$sn;
          break;
          case 3:
              return "h".$sn;
          break;
          default:
              return 0;
          break;
      }
 }
?>
<?php
include 'include.php';
$conn=sql_connect("../sql1");
 //error_reporting(0);
 if($_GET['cache']=="1" || $_GET['cache']=="2"){
   if($_GET['cache']=="1"){
      $next=3;
      $type="hotel";
   }
   else if($_GET['cache']=="2"){
      $next=4;
      $type="student";
   }
   if(strcmp($_GET['password'],$_GET['re_password'])!=0){
      echo ' not same password!!';
   }
   else{
   $id=hash("md5",tostring());
    $qry=mysqli_query($conn,"INSERT INTO `hotel` 
    VALUES 
        (   '0',
            '".$_GET['a_name']."',
            '".$type."',
            '".$_GET['phone']."',
            '".hash("md5",$_GET['re_password'])."',
            '".$id."'
            );
          ");
    if(!$qry){echo "error::".mysqli_error($conn);echo "something went wrong!!";}
    else {
      $qry=mysqli_query($conn,"select * from `hotel` where 
            phone_number='".$_GET['phone']."' and 
            name='".$_GET['a_name']."' and id='".$id."'");
      $data=mysqli_fetch_all($qry);
      session_start();
      $_SESSION['name']=$data[0][1];
      $_SESSION['type']=$data[0][2];
      $_SESSION['phone']=$data[0][3];
      $_SESSION['id']=$data[0][5];       ///sn as id for now
      mysqli_close($conn);         
      header("Location: /add_info.php?cache=$next");
    }
 }
}
else if($_POST['cache']=="3"){
   session_start();
      $qry=mysqli_query($conn,"select max(sn) from hotel_bio");
      if(!$qry){echo "error::".mysqli_error($conn);echo "something went wrong!!";}
      $data=mysqli_fetch_all($qry);
      $id=hotelid($data[0][0]+1);
      add_image("parent/".$_SESSION['phone']);
      $qry=mysqli_query($conn,"INSERT INTO `hotel_bio` 
      VALUES 
          (   '0',
              '".$_SESSION['id']."',
              '".$_SESSION['name']."',
              '".$_POST['manager_name']."',
              'parent/".$_SESSION['phone']."',
              '".$_POST['email']."',
              '".$_POST['address']."',
              '".$id."',
              '".$_POST['open_time']."',
              '".$_POST['close_time']."',
              '".$_POST['hotel_bio']."'
              );
            ");
      if(!$qry){echo "error::".mysqli_error($conn);echo "something went wrong!!";}
      else {        
        header("Location: /profile.php");
      }
}
else if($_POST['cache']=="4"){
   session_start();
      add_image("child/".$_SESSION['phone']);
      $qry=mysqli_query($conn,"INSERT INTO `student_bio` 
      VALUES 
          (   '0',
              '".$_SESSION['id']."',
              'child/".$_SESSION['phone']."',
              '".$_POST['email']."',
              '".$_POST['address']."',
              ''
              );
            ");
      if(!$qry){echo "error::".mysqli_error($conn);echo "something went wrong!!";}
      else {        
        header("Location: /profile.php");
      }
}
else{
   echo "not correct cache";
}
?> 